

Installation
-----

```bash
cd your_project

pip install requests_limit
```



